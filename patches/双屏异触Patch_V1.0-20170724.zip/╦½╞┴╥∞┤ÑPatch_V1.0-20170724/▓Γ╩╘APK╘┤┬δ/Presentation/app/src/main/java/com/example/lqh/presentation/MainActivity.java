package com.example.lqh.presentation;

import android.app.Presentation;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Resources;
import android.hardware.display.DisplayManager;
import android.media.MediaRouter;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String TAG = "MainActivity";
    private int[] color = new int[]{R.color.blue, R.color.black, R.color.pink, R.color.yellow};
    int index = 0;
    int flag = 0;    //witch method used to show presentation 0.none 1. mediarouter 2.displaymanager
    private Button bt_show_mt;
    private Button bt_show_dm;
    private Button bt_cancel;
    private Button bt_change;
    private FrameLayout frameLayout;
    private Button bt_presentation;


    private Presentation mPresentation;
    private Display mDisplay;

    private MediaRouter mMediaRouter;
    private DisplayManager mDisplayManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bt_show_mt = (Button) findViewById(R.id.button);
        bt_show_dm = (Button) findViewById(R.id.button2);
        bt_change = (Button) findViewById(R.id.button3);
        bt_cancel = (Button) findViewById(R.id.button4);
        bt_show_mt.setOnClickListener(this);
        bt_show_dm.setOnClickListener(this);
        bt_cancel.setOnClickListener(this);
        bt_change.setOnClickListener(this);
        mMediaRouter = (MediaRouter) this.getSystemService(Context.MEDIA_ROUTER_SERVICE);
        mDisplayManager = (DisplayManager) this.getSystemService(Context.DISPLAY_SERVICE);
    }

    //onResume和onPause一般用来进行对presentsatoin中的内容进行额外的处理
    @Override
    protected void onResume() {
        super.onResume();
        // Listen for changes to media routes.
        mMediaRouter.addCallback(MediaRouter.ROUTE_TYPE_LIVE_VIDEO, mMediaRouterCallback);
        // Register to receive events from the display manager.
        mDisplayManager.registerDisplayListener(mDisplayListener, null);
        Show(flag);
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Listen for changes to media routes.
        mMediaRouter.removeCallback(mMediaRouterCallback);
        mDisplayManager.unregisterDisplayListener(mDisplayListener);
    }

    @Override
    protected void onStop() {
        super.onStop();
        // Dismiss the presentation when the activity is not visible.
        if (mPresentation != null) {
            Log.i(TAG, "Dismissing presentation because the activity is no longer visible.");
            mPresentation.dismiss();
            mPresentation = null;
            //  flag=0;
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button:// Use MediaRouter to choose display
                if (flag != 1) {
                    ShowPresentationByMediarouter();
                    flag = 1;
                }
                break;
            case R.id.button2:// Use DisplayManager to choose display
                if (flag != 2) {
                    ShowPresentationByDisplaymanager();
                    flag = 2;
                }
                break;
            case R.id.button3://Change content of presentation
                if (index > 3) {
                    index = 0;
                }
                if (frameLayout != null) {
                    Log.i(TAG, "setBackgroundColor with index " + index);
                    frameLayout.setBackgroundColor(color[index]);
                    ++index;
                }
                break;
            case R.id.button4://Dissmiss presentation
                if (mPresentation != null && flag != 0) {
                    Log.i(TAG, "Dismissing presentation because the activity is no longer visible.");
                    mPresentation.dismiss();
                    mPresentation = null;
                    flag = 0;
                }
                break;
        }
    }

    private void Show(int flag) {
        switch (flag) {
            case 1:
                ShowPresentationByMediarouter();
                break;
            case 2:
                ShowPresentationByDisplaymanager();
                break;
        }
    }

    private void ShowPresentationByDisplaymanager() {
        Display[] presentationDisplays = mDisplayManager.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION);
        if (presentationDisplays.length > 0) {
            // If there is more than one suitable presentation display, then we could consider
            // giving the user a choice.  For this example, we simply choose the first display
            // which is the one the system recommends as the preferred presentation display.
            Display display = presentationDisplays[0];
            showPresentation(display);
        }
    }

    private void ShowPresentationByMediarouter() {
        MediaRouter.RouteInfo route = mMediaRouter.getSelectedRoute(MediaRouter.ROUTE_TYPE_LIVE_VIDEO);//选择类型
        if (route != null) {
            mDisplay = route.getPresentationDisplay();
            showPresentation(mDisplay);
        }
    }

    private void showPresentation(Display presentationDisplay) {
        // Dismiss the current presentation if the display has changed.
        if (mPresentation != null && mPresentation.getDisplay() != presentationDisplay) {
            Log.i(TAG, "Dismissing presentation because the current route no longer "
                    + "has a presentation display.");
            mPresentation.dismiss();
            mPresentation = null;
        }
        // Show a new presentation if needed.
        if (mPresentation == null && presentationDisplay != null) {
            Log.i(TAG, "Showing presentation on display: " + presentationDisplay);
            mPresentation = new MyPresentation(this, presentationDisplay);
            //  mPresentation.setOnDismissListener(mOnDismissListener);
            try {
                mPresentation.show();
            } catch (WindowManager.InvalidDisplayException ex) {
                Log.w(TAG, "Couldn't show presentation!  Display was removed in "
                        + "the meantime.", ex);
                mPresentation = null;
            }
        }
    }

    //MediaRouter检测HDMI线的拔出和插入用的。
    private final MediaRouter.SimpleCallback mMediaRouterCallback =
            new MediaRouter.SimpleCallback() {
                @Override
                public void onRouteSelected(MediaRouter router, int type, MediaRouter.RouteInfo info) {
                    Log.d(TAG, "onRouteSelected: type=" + type + ", info=" + info);
                    Show(flag);
                }

                @Override
                public void onRouteUnselected(MediaRouter router, int type, MediaRouter.RouteInfo info) {
                    Log.d(TAG, "onRouteUnselected: type=" + type + ", info=" + info);
                    Show(flag);
                }

                @Override
                public void onRoutePresentationDisplayChanged(MediaRouter router, MediaRouter.RouteInfo info) {
                    Log.d(TAG, "onRoutePresentationDisplayChanged: info=" + info);
                    Show(flag);
                }
            };

    //DisplayManager检测HDMI线的拔出和插入用的。
    private final DisplayManager.DisplayListener mDisplayListener =
            new DisplayManager.DisplayListener() {
                @Override
                public void onDisplayAdded(int displayId) {
                    Log.d(TAG, "Display #" + displayId + " added.");
                    Show(flag);
                }

                @Override
                public void onDisplayChanged(int displayId) {
                    Log.d(TAG, "Display #" + displayId + " changed.");
                    Show(flag);
                }

                @Override
                public void onDisplayRemoved(int displayId) {
                    Log.d(TAG, "Display #" + displayId + " removed.");
                    Show(flag);
                }
            };

    private final class MyPresentation extends Presentation {


        public MyPresentation(Context context, Display display) {
            super(context, display);
        }

//        public MyPresentation(Context context, Display display,
//                              DemoPresentationContents contents) {
//            super(context, display);
//            mContents = contents;
//        }

        /**
         * Sets the preferred display mode id for the presentation.
         */
        public void setPreferredDisplayMode(int modeId) {
            //       mContents.displayModeId = modeId;

            WindowManager.LayoutParams params = getWindow().getAttributes();
            params.preferredDisplayModeId = modeId;
            getWindow().setAttributes(params);
        }

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            // Be sure to call the super class.
            super.onCreate(savedInstanceState);

            // Get the resources for the context of the presentation.
            // Notice that we are getting the resources from the context of the presentation.
            Resources r = getContext().getResources();

            // Inflate the layout.
            setContentView(R.layout.presentation_content);
            frameLayout = (FrameLayout) findViewById(R.id.frameLayout);
            bt_presentation = (Button) findViewById(R.id.bt_presentation);
            bt_presentation.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AlertDialog dialog = new AlertDialog.Builder(MainActivity.this)
                            .setTitle("Dialog")
                            .setMessage("Prsentation Click Test")
                            .setPositiveButton("OK", new OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            }).create();
                    dialog.show();
                }
            });

        }
    }


}
