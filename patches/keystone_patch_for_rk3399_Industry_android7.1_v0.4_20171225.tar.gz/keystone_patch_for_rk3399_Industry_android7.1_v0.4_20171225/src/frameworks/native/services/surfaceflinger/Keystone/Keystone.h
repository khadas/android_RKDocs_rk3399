#ifndef SF_GLES20RENDERENGINE_KEYSTONE_H_
#define SF_GLES20RENDERENGINE_KEYSTONE_H_

typedef unsigned int uint32_t;

#include <stdint.h>
#include <sys/types.h>

#include <GLES2/gl2.h>

#include "../RenderEngine/Description.h"
#include "../RenderEngine/ProgramCache.h"

// ---------------------------------------------------------------------------
namespace android {
// ---------------------------------------------------------------------------

class String8;

class Keystone {

public:
    Keystone();
    virtual ~Keystone();

    bool isNeedKeystone(int32_t displayType, int32_t displayId);
    int setTargetDpyXY(int32_t displayType, int32_t displayId, int x, int y);
    void onBeginGroup(GLuint name, GLuint tname);
    void onEndGroup(GLuint texCoords, GLuint position);
    void setScreenSize(uint32_t w, uint32_t h);

    static String8 generateVertexShader(const ProgramCache::Key& needs);
    static String8 generateFragmentShader(const ProgramCache::Key& needs);

protected:

    struct MeshBuffer{
        GLuint bufferHandle;
        GLuint last_x;
        GLuint last_y;
        GLboolean reCompute;
    };

    struct MeshBuffer mMeshData;

};

// ---------------------------------------------------------------------------
}; // namespace android
// ---------------------------------------------------------------------------

#endif /* SF_GLES20RENDERENGINE_KEYSTONE_H_ */
